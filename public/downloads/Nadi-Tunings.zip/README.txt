NADI TUNING FILES - just intonation ragas
Sattvagenic - sattvagenic.com/nadi
================================================================

WHY THESE EXIST

Nadi tunes its seven resonators in JUST INTONATION - intervals built
from small whole-number ratios (3/2, 5/4, 9/8), the way the ragas were
always intended to be tuned.

Equal temperament, which every synth and piano uses by default, divides
the octave into twelve equal steps instead. The two systems do not line
up: the just major third sits about 14 cents flat of the equal-tempered
one, the sixth about 16 cents flat.

That mismatch is why Nadi can seem to fight an existing track. The notes
agree; the tuning doesn't, so you hear beating.

These files fix it at the root. Load one and your instruments play in
exactly the same tuning as Nadi's resonators - they lock together and
the resonance blooms instead of beating.

WHICH FOLDER

  Ableton-Live-ascl/    .ascl files for Live 12 and later.
                        Includes swara note names in the piano roll.

  Other-Software-scl/   .scl files in the original Scala format, for
                        synths with their own tuning support - Spire,
                        Serum, Pigments, Diva, Zebra, and many others.

  The tunings are identical; only the file format differs.

ABLETON LIVE 12

  1. Drag an .ascl file into the Tuning section beneath Live's Browser
     sidebar - or drop it into a folder in Live's Places and it appears
     under the Tunings label, tagged User.
  2. Double-click it to activate. The piano roll now shows the raga's
     own notes instead of standard MIDI notes.
  3. Set Nadi's Rasa to the matching raga.
  4. Play. Everything is in the same tuning.

  Note: Live retunes third-party plug-ins only if they are MPE-capable
  AND their pitch bend range is set to 48 semitones. Many are not. For
  those, load the .scl into the synth's own tuning section instead.

OTHER SYNTHS (Spire, Serum, Pigments, Diva...)

  Load the .scl file in the synth's own tuning or microtuning section.
  This works regardless of your DAW, and doesn't depend on MPE.
  Then set Nadi's Rasa to the matching raga.

  Some synths also want a keyboard mapping (.kbm) file. If yours does
  and none is supplied, its default mapping is normally correct: the
  scale starts at the root note and repeats every octave.

WHICH FILE

  One file per Nadi raga, named to match the Rasa menu exactly.
  Nadi_Chromatic holds all twelve degrees Nadi uses - for Custom rasa,
  or for free playing in Nadi's tuning without a fixed raga.

NOTE NAMES

  Capitals are shuddha (natural) degrees, lower case are komal
  (flattened), and Ma+ is tivra Ma:

     Sa  re  Re  ga  Ga  Ma  Ma+  Pa  dha  Dha  ni  Ni

REFERENCE PITCH

  Referenced to C3 = 261.6256 Hz. Nadi's Sa dial is fully continuous,
  so set Sa to your chosen root and the relationships hold at any pitch.
